const datas = [
  {
    id: '1',
    title: 'Baju',
    harga: '30000',
    subtitle: 'Lorem ipsum dolor sit amet et nuncat mergitur',
    image: 'https://s1.bukalapak.com/img/61981045003/s-463-463/data.jpeg.webp',
  },
  {
    id: '2',
    title: 'Baju Ara Ara johanes',
    harga: '40000',
    subtitle: 'Lorem ipsum dolor sit amet et nuncat mergitur',
    image: 'https://imgx.parapuan.co/crop/0x0:0x0/x/photo/2023/05/13/rekomendasi-kostum-cosplayjpg-20230513023735.jpg',
  },
  {
    id: '3',
    title: 'White Pocket Sunset',
    harga: '50000',
    subtitle: 'Lorem ipsum dolor sit amet et nuncat ',
    image: 'https://ae01.alicdn.com/kf/Sa6a1a7d75991407fb655297f32e642ebS/Baju-Seragam-Cosplay-Anime-YouTuber-Vumbi-Hololive-Mayuni-Fuyuko-Pakaian-Seragam-Kostum-Cosplay-Kustom-Permainan-Pakaian.jpg',
  },
  {
    id: '4',
    title: 'Acrocorinth, Greece',
    harga: '90000',
    subtitle: 'Lorem ipsum dolor sit amet et nuncat mergitur',
    image: 'https://i.imgur.com/KZsmUi2l.jpg',
  },
  {
    id: '5',
    title: 'Baju Japir',
    harga: '30000',
    subtitle: 'Lorem ipsum dolor sit amet',
    image: 'https://i.imgur.com/2nCt3Sbl.jpg',
  },
];

export default datas